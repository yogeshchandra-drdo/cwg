/*
 * Host.cc
 *
 *  Created on: 25-Apr-2018
 *      Author: QMS
 */

#include <stdio.h>
#include <string.h>
#include <omnetpp.h>
#include "cwg1_m.h"
using namespace omnetpp;

/**
    Cyber Wargame
 */

enum AttackType {dos, syn, fragment};
enum AttackInt {low=1, high=2};
enum State {up, down};

class Host : public cSimpleModule
{
    private:
        simsignal_t arrivalSignal;
        float cpu, ram, net;
        AttackType attackType;
        AttackInt attackInt;
        State state;
        void updateState();
    protected:
        virtual CyberMsg *generateMessage();
        virtual void forwardMessage(CyberMsg *msg);
        virtual void refreshDisplay() const override;
        virtual void initialize() override;
        virtual void handleMessage(cMessage *msg) override;

};

Define_Module(Host);

void Host::initialize()
{

    cpu = 100; ram = 100; net = 100;
    state = up;
    arrivalSignal = registerSignal("arrival");

    if (getIndex() == 0) {
        // Boot the process scheduling the initial message as a self-message.

        CyberMsg *msg = generateMessage();
        scheduleAt(0.0, msg);
    }
}

void Host::updateState()
{
    attackType = dos;
    attackInt = low;
    switch (attackType)
    {
    case dos:
        (cpu > 0) ? cpu -= 10*attackInt : 0;
        (ram > 0) ? ram -= 10*attackInt : 0;
        (net > 0) ? net -= 10*attackInt : 0;
        break;

    case syn:
        //(cpu > 0) ? cpu -= 10*attackInt : 0;
        (ram > 0) ? ram -= 10*attackInt : 0;
        (net > 0) ? net -= 10*attackInt : 0;
        break;

    case fragment:
        //(cpu > 0) ? cpu -= 10*attackInt : 0;
        (ram > 0) ? ram -= 10*attackInt : 0;
        (net > 0) ? net -= 10*attackInt : 0;
        break;
    }

    cDisplayString& displayString = getDisplayString();
    displayString.setTagArg("i", 1, "red");
    //displayString.setTagArg("r", 0, 20);
    //displayString.setTagArg("r", 1, "red");

    if (cpu <= 0 || ram <=0 || net <=0)
    {
        state = down;
        displayString.setTagArg("i2", 0, "status/stop");
    }
}

void Host::handleMessage(cMessage *msg)
{
    CyberMsg *msg1 = check_and_cast<CyberMsg *>(msg);

    if (msg1->getDestination() == getIndex()) {
        // Message arrived
        int hopcount = msg1->getHopCount();
        // send a signal
        emit(arrivalSignal, hopcount);
        EV << "Message " << msg1 << " arrived after " << hopcount << " hops.\n";
        bubble("Attacked!");
        delete msg1;

        updateState();

        if (hasGUI()) {
            char label[50];
            // Write last hop count to string
            sprintf(label, "last hopCount = %d", hopcount);
            // Get pointer to figure
            cCanvas *canvas = getParentModule()->getCanvas();
            cTextFigure *textFigure = check_and_cast<cTextFigure*>(canvas->getFigure("lasthopcount"));
            // Update figure text
            textFigure->setText(label);

            //cImageFigure *imageFigure = check_and_cast<cImageFigure*>(canvas->getFigure("maps/usa"));
            //imageFigure->setImageName("maps/usa");
        }

     // Generate another one.
        EV << "Generating another message: ";
        CyberMsg *newmsg = generateMessage();
        EV << newmsg << endl;
        forwardMessage(newmsg);
    }
    else {
        // We need to forward the message.
        forwardMessage(msg1);
    }
}

CyberMsg *Host::generateMessage()
{
    // Produce source and destination addresses.
    int src = getIndex();  // our module index
    int n = getVectorSize();  // module vector size
    int dest = intuniform(0, n-2);
    if (dest >= src)
        dest++;

    char msgname[20];
    sprintf(msgname, "attack-%d-to-%d", src, dest);

    // Create message object and set source and destination field.
    CyberMsg *msg = new CyberMsg(msgname);
    msg->setSource(src);
    msg->setDestination(dest);
    return msg;
}
void Host::forwardMessage(CyberMsg *msg)
{
    // Increment hop count.
    msg->setHopCount(msg->getHopCount()+1);

    // Same routing as before: random gate.
    int n = gateSize("gate");
    int k = intuniform(0, n-1);

    EV << "Forwarding message " << msg << " on gate[" << k << "]\n";
    send(msg, "gate$o", k);
}

void Host::refreshDisplay() const
{
    char buf[40];
    sprintf(buf, "cpu: %.f ram: %.f", cpu, ram);
    cDisplayString& displayString = getDisplayString();
    displayString.setTagArg("t", 0, buf);
    //displayString.setTagArg("i", 1, "red");
}
